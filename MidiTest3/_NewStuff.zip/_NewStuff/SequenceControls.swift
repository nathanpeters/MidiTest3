//
//  SequenceControls.swift
//  MidiTest3
//
//  Created by Nathan Peters on 4/21/25.
//
import SwiftUI

    struct SequenceControls: View{
        var body: some View{
            VStack{
                Text("Sequence Controls")
            }
        }
    }
