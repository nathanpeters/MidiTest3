import SwiftUI

class SequencePlayer: ObservableObject {
    private var timer: Timer?
    private let midiSender = MIDISender()
    private var currentStep = 0
    
    var model: SequenceModel
    var tempo: Double = 120 // default BPM
    var noteLength: TimeInterval = 0.2
    @Published var isPlaying = false // Track whether the sequence is playing
    
    init(model: SequenceModel) {
        self.model = model
    }

    func start() {
        guard !isPlaying else { return } // Prevent starting if already playing
        
        // Mark the sequence as playing
        isPlaying = true
        currentStep = 0
        
        // Start the timer with the correct interval based on the tempo
        let interval = 60.0 / tempo
        timer = Timer.scheduledTimer(withTimeInterval: interval, repeats: true) { _ in
            self.playStep()
        }
    }

    func stop() {
        guard isPlaying else { return } // Prevent stopping if not playing
        
        // Mark the sequence as stopped
        isPlaying = false
        
        // Invalidate the timer to stop playback
        timer?.invalidate()
        timer = nil
    }

    private func playStep() {
        // Access the current step directly from the model's steps array
        let step = model.steps[currentStep % model.steps.count]
        
        if step.isActive {
            midiSender.send(noteOn: step.note, velocity: 100)
            DispatchQueue.main.asyncAfter(deadline: .now() + noteLength) {
                self.midiSender.send(noteOff: step.note)
            }
        }
        
        currentStep += 1
    }
}
