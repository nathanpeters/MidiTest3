//
//  MidiTest3App.swift
//  MidiTest3
//
//  Created by Nathan Peters on 4/8/25.
//

import SwiftUI

@main
struct MidiTest3App: App {
    var body: some Scene {
        WindowGroup {
            MegaView()
        }
    }
}
