import SwiftUI

struct MegaView: View {
    
    //MAIN TAB NAV
    var body: some View {
        TabView {
            Tab("Sequencer", systemImage: "pianokeys") {
                ZStack {
                    Color(.systemBackground)
                        .ignoresSafeArea()
                    Sequencer()
                }
            }
            Tab("Prototype", systemImage: "testtube.2") {
                ZStack {
                    Color(.systemBackground)
                        .ignoresSafeArea()
                    MainView()
                }
            }
            Tab("Settings", systemImage: "gearshape") {
                ZStack {
                    Color(.systemBackground)
                        .ignoresSafeArea()
                    MIDISettingsView()
                }
            }
        }
    }
}
    
    
//    //SEQUENCER VIEW
//    struct Sequencer: View{
//        enum Mode {
//            case control
//            case details
//        }
//        
//        @State private var mode: Mode = .details
//        @StateObject private var sequenceModel = SequenceModel()
//        @StateObject private var model = SequenceModel()
//        @StateObject var deviceManager = MIDIDeviceManager()
//        @StateObject private var player: SequencePlayer
//        
//        init() {
//            let sequenceModel = SequenceModel()
//            _model = StateObject(wrappedValue: sequenceModel)
//            _player = StateObject(wrappedValue: SequencePlayer(model: sequenceModel))
//        }
//        
//        
//        var body: some View {
//            GeometryReader { geo in
//                ZStack{
//                    SequenceControls()
//                    SequenceDetails(mode: $mode, model: model, deviceManager: deviceManager, player: player)
//                        .offset(x: mode == .details ? -geo.size.width * 0.02 : -geo.size.width * 0.805)
//                        .animation(.easeInOut(duration: 0.4), value: mode)
//                }
//                
//            }
//            .background(Color.theme.backgroundSequence)
//            
//        }
//    }
    
    // CONTROLS VIEW
//    struct SequenceControls: View{
//        var body: some View{
//            VStack{
//                Text("Sequence Controls")
//            }
//        }
//    }
    
    
    
    //SEQUENCE VIEW
    
//    struct SequenceDetails: View {
//        @Binding var mode: MegaView.Sequencer.Mode
//        @State private var noteValue: Double = 20
//        @State private var zoomFactor: CGFloat?
//        @GestureState private var magnifyBy = CGFloat(1.0)
//        @ObservedObject var model: SequenceModel
//        @ObservedObject var deviceManager: MIDIDeviceManager
//        @ObservedObject var player: SequencePlayer
//        
//        var body: some View {
//            GeometryReader { geo in
//                let availableHeight: CGFloat = geo.size.height
//                VStack(spacing: 0) {
//                    ScrollView(.vertical, showsIndicators: true) {
//                        let targetHeight = geo.size.height * 0.85
//                        let rowCount: CGFloat = 16
//                        let spacingRatio: CGFloat = 0.5
//                        let baseRowHeight = targetHeight / (rowCount + spacingRatio * (rowCount - 1))
//                        let idealZoom = 1.0
//                        let effectiveZoom = min(max((zoomFactor ?? 1.0) * magnifyBy, 1.0), 2.0)
//                        
//                        let layout = StepLayout(
//                            width: geo.size.width * 0.122,
//                            height: baseRowHeight * effectiveZoom,
//                            spacing: geo.size.width * 0.02,
//                            fontSize: geo.size.height * 0.02,
//                            scale: geo.size.height * 0.001
//                        )
//                        
//                        ZStack {
//                            Color.theme.backgroundSequence
//                            StepCollection(model: model, layout: layout)
//                        }
//                        .onAppear {
//                            if zoomFactor == nil {
//                                zoomFactor = idealZoom
//                            }
//                        }
//                        .highPriorityGesture(
//                            MagnificationGesture()
//                                .updating($magnifyBy) { current, gestureState, _ in
//                                    gestureState = current
//                                }
//                                .onEnded { finalScale in
//                                    zoomFactor = min(max((zoomFactor ?? idealZoom) * finalScale, 1.0), 2.0)
//                                }
//                        )
//                    }
//                    .frame(height: availableHeight * 0.85)
//                    
//                    // Non-scrolling portion
//                    HStack{
//                        Text("test\(player.isPlaying)")
//                        Spacer()
//                        VStack(spacing: availableHeight * 0.015) {
//                            let localHeight = availableHeight * 0.15
//                            Spacer()
//                            
//                            // Play/Stop Button
//                            Button(action: {
//                                if player.isPlaying {
//                                    player.stop() // Stop the player
//                                } else {
//                                    player.start() // Start the player
//                                }
//                            }) {
//                                Image(systemName: player.isPlaying ? "stop.fill" : "arrowtriangle.right.fill")
//                                    .resizable()
//                                    .frame(width: 18, height: 18)
//                            }
//                            .frame(width: geo.size.width * 0.122, height: localHeight * 0.38)
//                            .foregroundColor(Color(red: 0.48, green: 0.75, blue: 0.78))
//                            .overlay(
//                                RoundedRectangle(cornerRadius: 3)
//                                    .stroke(Color.white.opacity(1), lineWidth: 2)
//                                    .strokeBorder(Color.gray.opacity(1), lineWidth: 1)
//                            )
//                            
//                            // Other controls (e.g., toggle between control and details mode)
//                            Button(action: {
//                                mode = (mode == .details) ? .control : .details
//                            }) {
//                                Image(systemName: "arrow.left.and.line.vertical.and.arrow.right")
//                                    .resizable()
//                                    .scaledToFit()
//                                    .frame(width: 18, height: 18)
//                            }
//                            .buttonStyle(NoPressEffectButtonStyle())
//                            .frame(width: geo.size.width * 0.122, height: localHeight * 0.18)
//                            .foregroundColor(Color.gray)
//                            .overlay(
//                                RoundedRectangle(cornerRadius: 3)
//                                    .stroke(Color.white.opacity(1), lineWidth: 2)
//                                    .strokeBorder(Color.gray.opacity(1), lineWidth: 1)
//                            )
//                            .padding(.horizontal, geo.size.width * 0.122 * 0.32)
//                            Spacer()
//                            Spacer()
//                        }
//                    }
//                    .frame(width: geo.size.width, height: availableHeight * 0.15)
//                    .background(Color.theme.backgroundSequence)
//                }
//                .padding(.top) // safe area
//            }
//        }
//    }
    
//    struct StepCollection: View {
//        @ObservedObject var model: SequenceModel
//        let layout: StepLayout
//
//        var body: some View {
//            VStack(spacing: layout.height / 2) {
//                ForEach(model.steps.indices, id: \.self) { index in
//                    StepRow(step: $model.steps[index], layout: layout)
//                }
//            }
//        }
//    }

    
//    struct StepRow: View {
//        @Binding var step: Step
//        let layout: StepLayout
//
//        var body: some View {
//            HStack(spacing: layout.spacing) {
//                NoteSlider(noteValue: $step.note)
//                ZStack {
//                    RoundedRectangle(cornerRadius: 4)
//                        .fill(Color.theme.buttonBackground)
//                        .stroke(Color.theme.buttonInset, lineWidth: 2)
//                        .strokeBorder(Color.theme.buttonOutline, lineWidth: 1)
//                        .frame(width: layout.width*1.3, height: layout.height)
//                    HStack(spacing: 0) {
//                        DecrementButton(step: $step, layout: layout, width: layout.width * 0.65)
//                        Divider().frame(height: layout.height)
//                            .background(Color.theme.buttonOutline)
//                        IncrementButton(step: $step, layout: layout, width: layout.width * 0.65)
//                    }
//                }
//                HStack(spacing:0){
//                    NoteLabel(note: step.note, layout: layout)
//                    StepToggle(isActive: $step.isActive, layout: layout)
//                        .padding(.leading, layout.width*0.32)
//                }
//            }
//            .padding(.horizontal, layout.width*0.32)
//        }
//    }

    
//    struct NoteLabel: View {
//        let note: UInt8
//        let layout: StepLayout
//
//        var body: some View {
//            ZStack {
//                RoundedRectangle(cornerRadius: 4)
//                    .fill(Color.theme.buttonBackground)
//                    .stroke(Color.theme.buttonInset)
//                    .frame(width: layout.width * 0.75, height: layout.height)
//
//                Text(noteName(for: note))
//                    .font(Font.custom("NanumGothicCoding", size: layout.fontSize))
//                    .foregroundColor(Color.theme.textDisplay)
//            }
//        }
//
//        func noteName(for note: UInt8) -> String {
//            let names = ["C", "C♯", "D", "D♯", "E", "F", "F♯", "G", "G♯", "A", "A♯", "B"]
//            let octave = Int(note) / 12 - 1
//            let name = names[Int(note) % 12]
//            return "\(name)\(octave)"
//        }
//    }
//
//    
//    struct NoteSlider: View {
//        @Binding var noteValue: UInt8
//
//        var body: some View {
//            Slider(
//                value: Binding(
//                    get: { Double(noteValue) },
//                    set: { noteValue = UInt8($0) }
//                ),
//                in: 1...127,
//                step: 1
//            )
//            .accentColor(Color.theme.lightedButtonIdle)
//        }
//    }
//    
//    struct IncrementButton: View {
//        @Binding var step: Step
//        let layout: StepLayout
//        let width: CGFloat
//
//        var body: some View {
//            Button(action: {
//                if step.note < 127 { step.note += 1 }
//            }) {
//                Image(systemName: "arrowtriangle.up.fill")
//                    .resizable()
//                    .frame(width: 16 * layout.scale, height: 10 * layout.scale)
//                    .frame(width: width)
//                    .foregroundColor(Color.theme.primaryAction)
//            }
//        }
//    }
//
//    struct DecrementButton: View {
//        @Binding var step: Step
//        let layout: StepLayout
//        let width: CGFloat
//
//        var body: some View {
//            Button(action: {
//                if step.note > 0 { step.note -= 1 }
//            }) {
//                Image(systemName: "arrowtriangle.down.fill")
//                    .resizable()
//                    .frame(width: 16 * layout.scale, height: 10 * layout.scale)
//                    .frame(width: width)
//                    .foregroundColor(Color.theme.primaryAction)
//            }
//        }
//    }
//    
//    struct StepToggle: View {
//        @Binding var isActive: Bool
//        let layout: StepLayout
//
//        var body: some View {
//            Button(action: {
//                isActive.toggle()
//            }) {
//                ZStack(alignment: .top) {
//                    RoundedRectangle(cornerRadius: 4)
//                        .fill(Color.theme.lightedButtonIdle.gradient)
//                        .stroke(Color.theme.buttonInset, lineWidth: 2)
//                        .strokeBorder(Color.theme.buttonOutline, lineWidth: 1)
//                        .frame(width: layout.width, height: layout.height)
//                    RoundedRectangle(cornerRadius: 2.5)
//                        .fill(Color.white.opacity(0.40))
//                        .frame(width: layout.width*0.93, height: layout.height*0.84)
//                }
//            }
//        }
//    }
    
//    struct NoPressEffectButtonStyle: ButtonStyle {
//        func makeBody(configuration: Configuration) -> some View {
//            configuration.label
//                .scaleEffect(1.0) // avoid press-in scaling
//                .animation(.easeInOut(duration: 0.4), value: configuration.isPressed)
//        }
//    }
//}


#Preview{
    MegaView()
}

